a = [i for i in range(10)]
for i in a[::2]:
    print(i)


